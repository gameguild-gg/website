#ifndef CAT_h
#define CAT_h
#include "IAgent.h"

namespace std{
  template<> struct hash<Point>{
    std::size_t  operator()(const Point& p) const noexcept{return p.hash();}
  };
}

struct Cat : public IAgent {
  std::pair<int,int> move(const std::vector<bool>& world, std::pair<int,int> catPos, int sideSize ) override{
    std::unordered_map<Point, Point> cameFrom; // to build the flowfield and build the path
    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> frontier;
    std::unordered_set<Point> frontierSet; // OPTIMIZATION to check faster if a point is in the queue
    std::vector<Point> path;

    Point catPosition;
    catPosition.x = catPos.first;
    catPosition.y = catPos.second;

    Node temp;
    temp.point.x = catPos.first;
    temp.point.y = catPos.second;
    temp.heuristic = distanceToBorder(temp.point, sideSize);

    frontier.push(temp);
    frontierSet.insert(temp.point);
    Point borderExit = {INT_MAX, INT_MAX};// if at the end of the loop we dont find a border, we have to return random points
    while(!frontier.empty())
    {
      Node current = frontier.top();
      frontier.pop();

      if(abs(current.point.x) == sideSize / 2 || abs(current.point.y) == sideSize / 2)
      {
        borderExit = current.point;
        break;
      }

      std::vector<Point> neigh = getVisitableNeighbors(world, sideSize, current.point);
      for(auto var : neigh)
      {
        if(frontierSet.find(var) == frontierSet.end())
        {
          Node n;
          n.point = var;
          n.accumulatedCost = current.accumulatedCost+1;
          n.heuristic = distanceToBorder(var, sideSize);
          frontier.push(n);
          frontierSet.insert(var);
          cameFrom[var] = current.point;
        }
      }
    }
    Point current = borderExit;
    while(current != catPosition)
    {
      path.push_back(current);
      current = cameFrom[current];
    }
    std::pair<int,int> go;
    go.first = path.back().x;
    go.second = path.back().y;
    return go;
  }

  std::vector<Point> getVisitableNeighbors(const std::vector<bool>& world, int sideSize, Point catPos)
  {
    std::vector<Point> newPos;
    int half = sideSize/2;
    int px = (half + catPos.x);
    int py = (half + catPos.y);
    int north = (half + catPos.y - 1);
    int south = (half + catPos.y + 1);
    int east = (half + catPos.x + 1);
    int west = (half + catPos.x - 1);

    if(py % 2 == 1)
    {
      if(!world[(north)*sideSize+east])
        newPos.emplace_back(catPos.x+1, catPos.y-1);
      if(!world[(north)*sideSize+px])
        newPos.emplace_back(catPos.x, catPos.y-1);
      if(!world[(py)*sideSize+east])
        newPos.emplace_back(catPos.x+1, catPos.y);
      if(!world[(south)*sideSize+east])
        newPos.emplace_back(catPos.x+1, catPos.y+1);
      if(!world[(south)*sideSize+px])
        newPos.emplace_back(catPos.x, catPos.y+1);
      if(!world[(py)*sideSize+west])
        newPos.emplace_back(catPos.x-1, catPos.y);
    }
    if(py % 2 == 0)
    {
      if(!world[(north)*sideSize+west])
        newPos.emplace_back(catPos.x-1, catPos.y-1);
      if(!world[(north)*sideSize+px])
        newPos.emplace_back(catPos.x, catPos.y-1);
      if(!world[(py)*sideSize+east])
        newPos.emplace_back(catPos.x+1, catPos.y);
      if(!world[(south)*sideSize+px])
        newPos.emplace_back(catPos.x, catPos.y+1);
      if(!world[(south)*sideSize+west])
        newPos.emplace_back(catPos.x-1, catPos.y+1);
      if(!world[(py)*sideSize+west])
        newPos.emplace_back(catPos.x-1, catPos.y);
    }
    return newPos;
  }

  int distanceToBorder(Point p, int sideSize)
  {
    //find the one that is greater in absolute value, X or y
    if(abs(p.y > abs(p.x)))
      return sideSize / 2 - abs(p.y);
    else
      return sideSize / 2 - abs(p.x);
  }
};



#endif